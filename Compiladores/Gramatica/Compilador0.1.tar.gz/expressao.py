def result(expre):
    operadores=['+','-','*','/']
    opright=['*','-']
    operador=[]
    operando=[]
    i=0
    while i < len(expre):
        if expre[i].isdigit():
            operando.append((expre[i]))
        if  expre[i] in operadores:
            if expre[i] in opright:
                operador.append
            operador.append(expre[i])
        if ')' in expre[i] or (len(operador)+len(operando))==len(expre):
            while len(operando) > 1 and len(operador):
                a=float(operando.pop())
                b=float(operando.pop())
                try:
                    operando.append((eval(f'{b}{operador.pop()}{a}')))
                except ZeroDivisionError:
                    print("divisão por zero")
                    break

        i+=1
    print (operando)

if __name__ == "__main__":
    result("2+3*2+3")
