'''
Que Deus tenha misericordia desta nação
'''
